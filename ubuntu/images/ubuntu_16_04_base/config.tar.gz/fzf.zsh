# Setup fzf
# ---------
if [[ ! "$PATH" == */home/root/.fzf/bin* ]]; then
  export PATH="${PATH:+${PATH}:}/home/root/.fzf/bin"
fi

# Auto-completion
# ---------------
[[ $- == *i* ]] && source "/home/root/.fzf/shell/completion.zsh" 2> /dev/null

# Key bindings
# ------------
# source "/home/root/.fzf/shell/key-bindings.zsh"
