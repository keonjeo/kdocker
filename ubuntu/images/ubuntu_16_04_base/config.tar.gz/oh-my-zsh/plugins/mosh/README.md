# Mosh Plugin

This plugin allows SSH tab completion for [mosh](https://mosh.org/) hostnames.

To use it, add `mosh` to the plugins array in your zshrc file:

```
plugins=(... mosh)
```
